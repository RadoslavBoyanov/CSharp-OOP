﻿using System;

namespace AuthorProblem
{
    internal class StartUp
    {
        [Author("George")]
        static void Main(string[] args)
        {
            AuthorAttribute author = new AuthorAttribute("Karl");
            Console.WriteLine(author.Name);
        }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method , AllowMultiple = true)]
    public class AuthorAttribute : Attribute
    {
        public AuthorAttribute(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }
    }
}
